Node
http://nodejs.org/download/


Glue
http://glue.readthedocs.org/en/latest/installation.html
http://www.python.org/ftp/python/2.7.2/python-2.7.2.msi
 - add glue path to environment paths



Compass
http://compass-style.org/install/
http://www.ruby-lang.org/en/downloads/
- and ruby (gem) to environment paths



Scout
http://mhs.github.io/scout-app/
	Creating project
		• In the directory containing css and scss folders go to commandline… 
		• type 'compass create'
		• Then edit the newly created 'config.rb' to point to the appropriate folders
		
	
	Configuring Scout
		• Click the "+" (you point to the folder you want to watch live)
			○ Point  to the 'includes' directory
		• Point the 'Input Folder' to 'scss'
		• Point the 'Output Folder' to 'css'
		• Click the play button to enable



Helpful
http://www.addictivetips.com/windows-tips/windows-7-elevated-command-prompt-in-context-menu/
http://www.rapidee.com/en/download

______________________

NPM installs
npm install -g jamjs 
npm install -g bbb 
npm install -g grunt-cli 
npm install -g requirejs 

// install only if the node-modules folder is missing or missing this content
npm install grunt --save-dev
npm install grunt-contrib-requirejs --save-dev
npm install requirejs
npm install grunt-dot-compiler
npm install grunt-linter
npm install grunt-json
npm install grunt-pngmin
npm install grunt-glue-nu
npm install grunt-rename --save-dev
npm install grunt-contrib-watch --save-dev
npm install grunt-contrib-sass --save-dev
