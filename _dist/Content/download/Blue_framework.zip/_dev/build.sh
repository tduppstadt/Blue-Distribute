echo " "
echo "_______________ BLUE BUILD MENU _______________"
echo " "
echo "1.  Build Project"
echo "    - Compile Templates"
echo "    - Build JS"
echo "    - Compile SCSS"
echo ""
echo "2.  Compile Templates & JS"
echo "    - from _dev/src/templates"
echo "    - to window.oTemplates"
echo "    - JS compiled to _dist/Content/js/release"
echo ""
echo "3.  Compile Templates"
echo "    - from _dev/src/templates"
echo "    - to window.oTemplates"
echo ""
echo "4.  Cache Bust"
echo "    - from _dev/src/index.html"
echo "    - to _dist/index.html"
echo ""
echo "5.  Compress PNG Images"
echo "    - from _dev/src/images/compression"
echo "    - to _dist/Content/images"
echo ""
echo "6.  Glue Sprites"
echo "    - from _dev/src/images/sprites"
echo "    - image to _dist/Content/images/sprites"
echo "    - SCSS to _dev/src/scss/_sprites"
echo ""
echo "7.  Compile SCSS"
echo "    - from _dev/src/scss"
echo "    - to _dist/Content/css"
echo ""
echo "8.  Watch SCSS"
echo "    - Listens and responds to updates from SCSS files."
echo "    - [Ctrl + Break] will stop the service."
echo ""
echo "0.  Cancel"
echo ""
echo "_______________"
echo ""

read -p "Option > " choice


if [ $choice -eq 0 ]; then
	exit 0
fi

echo ""
echo "Executing ..."
echo ""

if [ $choice -eq 1 ]; then
	grunt --pagename=project build;
	echo " "
	echo "__ BUILD COMPLETE __"
	echo " "
fi

if [ $choice -eq 2 ]; then
	grunt --pagename=project buildJS;
	echo " "
	echo "__ TEMPLATES and JS BUILD COMPILED __"
	echo " "
fi

if [ $choice -eq 3 ]; then
	grunt --pagename=project buildTemplate;
	echo " "
	echo "__ TEMPLATES COMPILED __"
	echo " "
fi

if [ $choice -eq 4 ]; then
	grunt --pagename=project cacheBust;
	echo " "
	echo "__ CACHE BUST COMPILED __"
	echo " "
fi

if [ $choice -eq 5 ]; then
	grunt --pagename=project compressImages;
	echo " "
	echo "__ IMAGE COMPRESSED __"
	echo " "
fi

if [ $choice -eq 6 ]; then
	grunt --pagename=project glueSprites;
	echo " "
	echo "__ GLUE SPRITES COMPLETE __"
	echo " "
fi

if [ $choice -eq 7 ]; then
	grunt --pagename=project compileScss;
	echo " "
	echo "__ SCSS COMPILED __"
	echo " "
fi

if [ $choice -eq 8 ]; then
	echo "Listening for SCSS changes ... "
	grunt --pagename=project watchScss;	
fi
